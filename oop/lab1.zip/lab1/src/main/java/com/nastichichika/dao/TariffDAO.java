package com.nastichichika.dao;

public class TariffDAO {
}
