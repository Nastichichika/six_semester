package com.nastichichika.servlets;

public class ChooseTariff {
}
