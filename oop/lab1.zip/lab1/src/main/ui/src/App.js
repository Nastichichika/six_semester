import React from "react";
import Content from "./Content";
function App() {
    return (
        <div className="App">
            <Content/>
            Hello
        </div>
    );
}

export default App;