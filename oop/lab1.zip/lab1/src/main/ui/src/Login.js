import React, {useState} from "react";
import $ from "jquery";
import {cleanCookies} from "universal-cookie/lib/utils";
import {Redirect} from "react-router-dom";

const Login = props => {
    const [user, setUser] = useState( props.initialUser );
    const [isCorrect, setFalse] = useState(true)
    const validateForm = () =>{
        return user.password.length > 0 && user.login.length > 0;
    }
    const handleInputChange = event => {
        const { login , password } = event.target
        setUser ( { ...login , [login]: password } )
    };

    if (props.loggedIn === true) {
        return <Redirect to="/"/>
    }

    const logIn = () => {
        $(document).on("submit", "#loginform", function(event) {
            cleanCookies();
            document.cookie = "LOGIN = " + user.login;
            document.cookie = "PASSWORD = " + user.password;
            $.get({
                url:'http://localhost:8080/lab1/login',
                crossDomain: true,
                xhrFields: { withCredentials: true },
                success: function(response){
                    if (response == null) {
                        setFalse(false);
                    }
                    else {
                        localStorage.setItem("username",response.name);
                        localStorage.setItem("id", response.id);
                        if(response.login === "admin")
                            window.location.href = '/admin=' + user.login;
                        else
                            window.location.href = '/user=' + user.login;
                    }
                }.bind(this),
            });

            event.preventDefault();
            user.password = ""
        }.bind(this));
    }
    return(
        <div>
            <form>
                <table>
                    <tbody>
                    <tr>
                        <td>Name:</td>
                        <td>
                            <input
                                type = "text"
                                name = "login"
                                value={ user.login }
                                onChange={ handleInputChange }
                            />
                        </td>
                    </tr>

                    <tr>
                        <td>Password:</td>
                        <td>
                            <input
                                type = "password"
                                name = "password"
                                value={user.password}
                                onChange={ handleInputChange }
                            />
                        </td>
                    </tr>

                    <tr>
                        <td colSpan='2'>
                            <center><button type="submit"
                                            onClick={ logIn }
                                            disabled={validateForm}>Log in</button></center>
                        </td>
                    </tr>
                    { !isCorrect ?
                        <tr>
                            <td colSpan='2'>Login or password was incorrect</td>
                        </tr> : null}
                    </tbody>
                </table>
            </form>
        </div>
    );
}

export default Login;