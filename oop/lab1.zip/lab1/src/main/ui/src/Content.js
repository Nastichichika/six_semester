
import {BrowserRouter, Route} from "react-router-dom";
import Login from "./Login";
import React, {useState, useEffect} from 'react';
import {readCookie} from "universal-cookie/lib/utils";

function Content() {
    const qs = require("qs")
    const [user, setUser] = useState(qs.parse(readCookie('LOGIN'), qs.parse(readCookie('PASSWORD'))));
    const initialUser = {
        login: '',
        password: ''
    };
    const [loggedIn, setLoggedIn] = useState(false)

    useEffect(() => {
            if (user) {
                if (user.token) {
                    if (user.token !== '') {
                        setLoggedIn(true)
                    }
                }
            }
        }, [user]
    )

    return (
        <div>
            <BrowserRouter>
                <div>
                    <Route exact path="/login">
                        <Login initialUser={initialUser} setUser={setUser} setLoggedIn={setLoggedIn}
                               loggedIn={loggedIn}/>
                    </Route>
                </div>
            </BrowserRouter>
        </div>
    );
}

export default Content;